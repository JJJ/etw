<?php

/**
 * Element Defaults: Block Grid Item
 */

return array(
	'id'           => '',
	'class'        => '',
	'style'        => '',
	'title'        => '',
	'content'      => ''
);