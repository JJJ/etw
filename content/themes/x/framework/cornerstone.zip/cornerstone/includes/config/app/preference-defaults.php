<?php

return array(
  'advanced_mode'            => false,
  'help_text'                => true,
  'show_wp_toolbar'          => false,
  'inspector_navigation'     => true,
  'content_builder_elements' => 'all'
);
